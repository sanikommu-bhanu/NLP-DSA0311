# ResolveAI complaint classification dataset

Files:
- complaints_dataset.csv: 500 labeled training examples (50 per category)
- test_dataset.csv: 100 labeled test examples (10 per category)

Categories (10):
Water, Electricity, Infrastructure, Sanitation, Transportation, Healthcare,
Education, Security, Internet, Financial Issues.

Important provenance note:
These are curated synthetic demonstration examples generated for the ResolveAI
academic project. They are not scraped from citizens, government complaint
systems, or a published real-world dataset. Do not describe them as real-world
collected data. For a research claim about real-world performance, replace or
supplement them with a suitably licensed public dataset and document its source.

Suggested implementation:
1. Load complaints_dataset.csv as training data.
2. Split features (complaint_text) and labels (category).
3. Train the JavaScript TF-IDF + Multinomial Naive Bayes implementation.
4. Load test_dataset.csv separately for evaluation.
5. Calculate accuracy, per-class precision, recall, F1 and confusion matrix.
6. Keep newly submitted complaints out of both training and test files.

The dataset is balanced by category. The test set is separate by file and uses
different sentence constructions/word combinations, but shares the category
vocabulary. Treat the resulting metrics as a classroom demonstration, not
evidence of generalization to all real-world complaints.
